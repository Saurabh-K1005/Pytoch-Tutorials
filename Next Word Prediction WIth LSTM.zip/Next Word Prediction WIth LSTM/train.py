import os
import torch
from torch.utils.data import DataLoader

from dataset import NextWordDataset
from model import LSTMModel
from utils import save_vocab

TEXT_PATH = "data/pizza.txt"
VOCAB_PATH = "artifacts/vocab.json"
MODEL_PATH = "artifacts/lstm_model.pth"

EPOCHS = 50
BATCH_SIZE = 32
LEARNING_RATE = 0.001

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

os.makedirs("artifacts", exist_ok=True)

dataset = NextWordDataset(TEXT_PATH)
dataloader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True)

model = LSTMModel(len(dataset.vocab)).to(device)

criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)

for epoch in range(EPOCHS):
    total_loss = 0

    for batch_x, batch_y in dataloader:
        batch_x = batch_x.to(device)
        batch_y = batch_y.to(device)

        optimizer.zero_grad()

        output = model(batch_x)
        loss = criterion(output, batch_y)

        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    print(f"Epoch: {epoch + 1}, Loss: {total_loss:.4f}")

save_vocab(dataset.vocab, VOCAB_PATH)
torch.save(model.state_dict(), MODEL_PATH)

print("Training complete.")
print(f"Vocabulary saved to: {VOCAB_PATH}")
print(f"Model saved to: {MODEL_PATH}")