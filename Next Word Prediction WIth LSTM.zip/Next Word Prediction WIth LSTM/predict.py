import torch
from nltk.tokenize import word_tokenize

from model import LSTMModel
from utils import load_vocab, text_to_indices

VOCAB_PATH = "artifacts/vocab.json"
MODEL_PATH = "artifacts/lstm_model.pth"

MAX_LENGTH = 61
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

vocab = load_vocab(VOCAB_PATH)

model = LSTMModel(len(vocab)).to(device)
model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
model.eval()


def predict_next_word(model, vocab, text):
    tokens = word_tokenize(text.lower())
    indices = text_to_indices(tokens, vocab)

    padded = [0] * (MAX_LENGTH - len(indices)) + indices
    tensor = torch.tensor([padded], dtype=torch.long).to(device)

    with torch.no_grad():
        output = model(tensor)

    predicted_index = torch.argmax(output, dim=1).item()
    predicted_word = list(vocab.keys())[predicted_index]

    return f"{text} {predicted_word}"


if __name__ == "__main__":
    text = input("Enter text: ")
    print(predict_next_word(model, vocab, text))