import json
from collections import Counter
from nltk.tokenize import word_tokenize


def build_vocab(tokens):
    vocab = {"<unk>": 0}

    for token in Counter(tokens).keys():
        if token not in vocab:
            vocab[token] = len(vocab)

    return vocab


def text_to_indices(tokens, vocab):
    return [
        vocab[token] if token in vocab else vocab["<unk>"]
        for token in tokens
    ]


def save_vocab(vocab, path):
    with open(path, "w", encoding="utf-8") as file:
        json.dump(vocab, file)


def load_vocab(path):
    with open(path, "r", encoding="utf-8") as file:
        return json.load(file)