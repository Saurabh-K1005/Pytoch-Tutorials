import torch
from torch.utils.data import Dataset
from nltk.tokenize import word_tokenize

from utils import build_vocab, text_to_indices


class NextWordDataset(Dataset):
    def __init__(self, text_path):
        with open(text_path, "r", encoding="utf-8") as file:
            self.text = file.read()

        self.tokens = word_tokenize(self.text.lower())
        self.vocab = build_vocab(self.tokens)

        input_sentences = self.text.split("\n")

        numerical_sentences = [
            text_to_indices(word_tokenize(sentence.lower()), self.vocab)
            for sentence in input_sentences
        ]

        training_sequences = []

        for sentence in numerical_sentences:
            for i in range(1, len(sentence)):
                training_sequences.append(sentence[:i + 1])

        max_len = max(len(sequence) for sequence in training_sequences)

        padded_sequences = [
            [0] * (max_len - len(sequence)) + sequence
            for sequence in training_sequences
        ]

        padded_tensor = torch.tensor(padded_sequences, dtype=torch.long)

        self.X = padded_tensor[:, :-1]
        self.y = padded_tensor[:, -1]

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, index):
        return self.X[index], self.y[index]