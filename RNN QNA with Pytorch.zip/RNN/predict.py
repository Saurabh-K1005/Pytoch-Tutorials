import torch

from model import SimpleRNN
from utils import load_vocab, text_to_indices, index_to_word, MODEL_PATH


THRESHOLD = 0.5


def load_model():
    vocab = load_vocab()
    model = SimpleRNN(vocab_size=len(vocab))

    model.load_state_dict(torch.load(MODEL_PATH, map_location=torch.device("cpu")))
    model.eval()

    return model, vocab


def predict(model, vocab, question, threshold=THRESHOLD):
    indices = text_to_indices(question, vocab)

    if len(indices) == 0:
        return "I don't know"

    question_tensor = torch.tensor(indices, dtype=torch.long).unsqueeze(0)

    with torch.no_grad():
        output = model(question_tensor)
        probabilities = torch.softmax(output, dim=1)

        confidence, predicted_index = torch.max(probabilities, dim=1)

    confidence = confidence.item()
    predicted_index = predicted_index.item()

    if confidence < threshold:
        return "I don't know"

    word = index_to_word(vocab)[predicted_index]
    return word


if __name__ == "__main__":
    model, vocab = load_model()

    question = "Who discovered gravity?"
    answer = predict(model, vocab, question)

    print(f"Question: {question}")
    print(f"Answer: {answer}")