import json
import os

VOCAB_PATH = "artifacts/vocab.json"
MODEL_PATH = "artifacts/rnn_model.pth"


def tokenize(text):
    text = text.lower()
    text = text.replace("?", "")
    text = text.replace("'", "")
    return text.split()


def build_vocab(df):
    vocab = {"<UKN>": 0}

    for _, row in df.iterrows():
        tokens = tokenize(row["question"]) + tokenize(row["answer"])

        for token in tokens:
            if token not in vocab:
                vocab[token] = len(vocab)

    return vocab


def text_to_indices(text, vocab):
    indices = []

    for token in tokenize(text):
        if token in vocab:
            indices.append(vocab[token])
        else:
            indices.append(vocab["<UKN>"])

    return indices


def save_vocab(vocab, path=VOCAB_PATH):
    os.makedirs(os.path.dirname(path), exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        json.dump(vocab, f, ensure_ascii=False, indent=2)


def load_vocab(path=VOCAB_PATH):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def index_to_word(vocab):
    return {index: word for word, index in vocab.items()}