import os

import pandas as pd
import torch
from torch.utils.data import DataLoader

from dataset import QADataset
from model import SimpleRNN
from utils import build_vocab, save_vocab, VOCAB_PATH, MODEL_PATH


CSV_PATH = "data/100_Unique_QA_Dataset.csv"
EPOCHS = 20
LEARNING_RATE = 0.01
BATCH_SIZE = 1


def train():
    df = pd.read_csv(CSV_PATH)

    vocab = build_vocab(df)
    save_vocab(vocab)

    dataset = QADataset(df, vocab)
    dataloader = DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
    )

    model = SimpleRNN(vocab_size=len(vocab))

    criterion = torch.nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)

    for epoch in range(EPOCHS):
        model.train()
        total_loss = 0

        for question, answer in dataloader:
            optimizer.zero_grad()

            output = model(question)

            # answer shape is (1, answer_length)
            # CrossEntropyLoss expects class indices of shape (batch_size,)
            loss = criterion(output, answer.squeeze(0))

            loss.backward()
            optimizer.step()

            total_loss += loss.item()

        average_loss = total_loss / len(dataloader)
        print(f"Epoch {epoch + 1}/{EPOCHS} | Loss: {average_loss:.4f}")

    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)

    torch.save(model.state_dict(), MODEL_PATH)
    print(f"\nModel saved to: {MODEL_PATH}")
    print(f"Vocabulary saved to: {VOCAB_PATH}")


if __name__ == "__main__":
    train()