import torch
from torch.utils.data import Dataset

from utils import text_to_indices


class QADataset(Dataset):
    def __init__(self, df, vocab):
        self.df = df
        self.vocab = vocab

    def __len__(self):
        return len(self.df)

    def __getitem__(self, index):
        row = self.df.iloc[index]

        question_indices = text_to_indices(row["question"], self.vocab)
        answer_indices = text_to_indices(row["answer"], self.vocab)

        return (
            torch.tensor(question_indices, dtype=torch.long),
            torch.tensor(answer_indices, dtype=torch.long),
        )