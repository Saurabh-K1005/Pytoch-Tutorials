import torch.nn as nn


class SimpleRNN(nn.Module):
    def __init__(self, vocab_size, embedding_dim=50, hidden_dim=64):
        super().__init__()

        self.embedding = nn.Embedding(vocab_size, embedding_dim)
        self.rnn = nn.RNN(
            input_size=embedding_dim,
            hidden_size=hidden_dim,
            batch_first=True,
        )
        self.fc = nn.Linear(hidden_dim, vocab_size)

    def forward(self, question):
        embedded = self.embedding(question)

        output, final_hidden = self.rnn(embedded)

        # final_hidden shape: (num_layers, batch_size, hidden_dim)
        final_hidden = final_hidden.squeeze(0)

        return self.fc(final_hidden)